/home/shravan/g-ctmqc-master/src/main.x < input.in
