cd $PBS_O_WORKDIR
./run.sh

