#!/bin/bash

echo "What type of calculation will you be running? (CT SH EH)"
read calculation

dir=output_$calculation
if [ -d $dir ] ; then
   rm -rf $dir
   mkdir $dir
else
   mkdir $dir
fi

echo "How many trajectories?"
read Ntraj

for i in $Ntraj
do
        path=$dir/${i}traj
        if [ ! -d $dir ] ; then
           mkdir $path
        else
           rm -rf $path
           mkdir $path
        fi

        path=$dir/${i}traj/coeff
        if [ ! -d $dir ] ; then
           mkdir $path
        else
           rm -rf $path
           mkdir $path
        fi

        path=$dir/${i}traj/trajectories
        if [ ! -d $dir ] ; then
           mkdir $path
        else
           rm -rf $path
           mkdir $path
        fi

done

echo "Give me the path to the source files"
read path_to_source

main_dir=$path_to_source

exec_dir=$dir/${i}traj
echo $main_dir'/main.x < input.in' > run.sh
chmod +x run.sh
mv run.sh $exec_dir

