../../src/main.x < input.in
