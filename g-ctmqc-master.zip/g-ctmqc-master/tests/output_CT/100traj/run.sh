/home/shravan/g-ctmqc-master/src/main.x/main.x < input.in
