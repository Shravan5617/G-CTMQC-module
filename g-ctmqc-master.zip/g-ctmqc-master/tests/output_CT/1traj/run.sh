/home/amber/GCTMQC/g-ctmqc-master/src/main.x < input.in
