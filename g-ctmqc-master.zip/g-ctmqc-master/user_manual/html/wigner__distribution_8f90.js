var wigner__distribution_8f90 =
[
    [ "gaussian_distribution", "wigner__distribution_8f90.html#a8a2514e4fdf5f85b28b8f4839b0c9d6c", null ],
    [ "initial_conditions", "wigner__distribution_8f90.html#aa2c951a0f0f444c1e379d3071007be0d", null ]
];