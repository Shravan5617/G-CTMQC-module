var kinds_8f90 =
[
    [ "dp", "kinds_8f90.html#a3592c80a445cf0d08dd82160a26d03ed", null ],
    [ "qp", "kinds_8f90.html#ab9ae202470c73e48421f18653821469b", null ]
];