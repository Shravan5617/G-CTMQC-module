var shopping_8f90 =
[
    [ "choose_bostate", "shopping_8f90.html#a23aaf41ee81dc0ce7779fa60ff5bca75", null ],
    [ "decoherence_coorection", "shopping_8f90.html#a1e73fe534aa7891ff431291c94ab2a16", null ],
    [ "hopping", "shopping_8f90.html#a337e7b61b2198ac64f3e6ee8a26abee6", null ],
    [ "momentum_correction", "shopping_8f90.html#ada8f3a7445deb0d07a5a8b43bb6f92c0", null ]
];