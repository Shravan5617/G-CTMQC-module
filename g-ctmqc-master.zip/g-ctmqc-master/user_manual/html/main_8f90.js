var main_8f90 =
[
    [ "main", "main_8f90.html#a8ec2266d83cd6c0b762cbcbc92c0af3d", null ],
    [ "read_dynamics_variables", "main_8f90.html#a553b0ffdb0106ce1f7167f60d3571d11", null ],
    [ "read_external_files", "main_8f90.html#a419dae0d1428e2b8273040b99d8ed60f", null ],
    [ "read_system_variables", "main_8f90.html#a54563b93e75f779e7df6869f981ab7d5", null ]
];