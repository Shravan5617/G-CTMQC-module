var coherence__corrections_8f90 =
[
    [ "accumulated_boforce", "coherence__corrections_8f90.html#af2109e0117f30acd569e33fc9642148f", null ],
    [ "quantum_momentum", "coherence__corrections_8f90.html#a982938b35739c7630cfcd56808b3882c", null ]
];