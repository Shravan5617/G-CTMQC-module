var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "analytical_potentials.f90", "analytical__potentials_8f90.html", "analytical__potentials_8f90" ],
    [ "atomic_masses.f90", "atomic__masses_8f90.html", "atomic__masses_8f90" ],
    [ "classical_evolution.f90", "classical__evolution_8f90.html", "classical__evolution_8f90" ],
    [ "coefficients_evolution.f90", "coefficients__evolution_8f90.html", "coefficients__evolution_8f90" ],
    [ "coherence_corrections.f90", "coherence__corrections_8f90.html", "coherence__corrections_8f90" ],
    [ "electronic_problem.f90", "electronic__problem_8f90.html", "electronic__problem_8f90" ],
    [ "kinds.f90", "kinds_8f90.html", "kinds_8f90" ],
    [ "main.f90", "main_8f90.html", "main_8f90" ],
    [ "output.f90", "output_8f90.html", "output_8f90" ],
    [ "shopping.f90", "shopping_8f90.html", "shopping_8f90" ],
    [ "time_evolution.f90", "time__evolution_8f90.html", "time__evolution_8f90" ],
    [ "tools.f90", "tools_8f90.html", "tools_8f90" ],
    [ "trajectories_selection.f90", "trajectories__selection_8f90.html", "trajectories__selection_8f90" ],
    [ "variables.f90", "variables_8f90.html", "variables_8f90" ],
    [ "wigner_distribution.f90", "wigner__distribution_8f90.html", "wigner__distribution_8f90" ]
];