var output_8f90 =
[
    [ "compute_energy", "output_8f90.html#a3d2caef916d021721f8eb6529aac2b4f", null ],
    [ "finalize_output", "output_8f90.html#aaa0414cf8105658e81912a3a41d752cb", null ],
    [ "initialize_output", "output_8f90.html#a86836a6f446885d459f048a9c0f393fb", null ],
    [ "plot", "output_8f90.html#a97d7611603ef98cdf4434e93ae5ea38d", null ],
    [ "plot_coefficients", "output_8f90.html#ac9b4106993ba0f3f342033fbb3965daa", null ],
    [ "plot_r_p_e", "output_8f90.html#ab306200f08bbb52e685f616adb4ed5ec", null ]
];