var coefficients__evolution_8f90 =
[
    [ "cdot", "coefficients__evolution_8f90.html#a2a7fdf5fc5474f67250bb3e0a5736bda", null ],
    [ "rk4_coeff", "coefficients__evolution_8f90.html#a2da8d322abba76ff6287134ddfb7e5cb", null ]
];