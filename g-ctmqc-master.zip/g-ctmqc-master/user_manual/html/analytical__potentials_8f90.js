var analytical__potentials_8f90 =
[
    [ "check_overlap", "analytical__potentials_8f90.html#a00c558ee0bcbfb79260952a640a9566c", null ],
    [ "diagonalize", "analytical__potentials_8f90.html#a659155b761baaa9ff7d93276000a0a7d", null ],
    [ "doublewell_potential", "analytical__potentials_8f90.html#ab188600744505c80905a6cae729ab5d1", null ],
    [ "ibr_potential", "analytical__potentials_8f90.html#ac4009180eb1b7add785ed27b62f042e5", null ],
    [ "nai_potential", "analytical__potentials_8f90.html#a8ca8bb2587935af18e85f86be58326e9", null ],
    [ "new_model_potentials", "analytical__potentials_8f90.html#aee08711dfb0552ba00cc2a8f005201df", null ],
    [ "non_adiabatic_couplings", "analytical__potentials_8f90.html#a18123f0763bb7734dbed0bad63a530fe", null ],
    [ "plot_potential", "analytical__potentials_8f90.html#aa199013ccfa8f3fdabd157b9c2bcba97", null ]
];