var searchData=
[
  ['classical_5fevolution_150',['classical_evolution',['../namespaceclassical__evolution.html',1,'']]],
  ['coefficients_5fevolution_151',['coefficients_evolution',['../namespacecoefficients__evolution.html',1,'']]],
  ['coherence_5fcorrections_152',['coherence_corrections',['../namespacecoherence__corrections.html',1,'']]]
];
