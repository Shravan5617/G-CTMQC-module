var searchData=
[
  ['variables_160',['variables',['../namespacevariables.html',1,'']]]
];
