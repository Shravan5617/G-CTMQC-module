var searchData=
[
  ['wigner_5fdistribution_173',['wigner_distribution',['../namespacewigner__distribution.html',1,'']]]
];
