var searchData=
[
  ['quantum_5fmomentum_211',['quantum_momentum',['../namespacecoherence__corrections.html#a982938b35739c7630cfcd56808b3882c',1,'coherence_corrections']]]
];
