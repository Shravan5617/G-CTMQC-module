var searchData=
[
  ['kinds_154',['kinds',['../namespacekinds.html',1,'']]]
];
