var searchData=
[
  ['hbar_240',['hbar',['../namespacevariables.html#a4f7c4b76127660a6ab1b9c2d0ced2757',1,'variables']]]
];
