var searchData=
[
  ['electronic_5fproblem_39',['electronic_problem',['../namespaceelectronic__problem.html',1,'']]],
  ['electronic_5fproblem_2ef90_40',['electronic_problem.f90',['../electronic__problem_8f90.html',1,'']]],
  ['evolution_41',['evolution',['../namespacetime__evolution.html#adf197da88c58ecd1eba0f4984aaf1b48',1,'time_evolution']]]
];
