var searchData=
[
  ['wigner_5fdistribution_161',['wigner_distribution',['../namespacewigner__distribution.html',1,'']]]
];
