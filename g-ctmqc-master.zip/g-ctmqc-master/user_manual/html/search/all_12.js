var searchData=
[
  ['select_5fcoupled_5ftrajectories_121',['select_coupled_trajectories',['../namespacetrajectories__selection.html#ab60ff06af8f5dbc681f6e615a315e367',1,'trajectories_selection']]],
  ['shopping_122',['shopping',['../namespaceshopping.html',1,'']]],
  ['shopping_2ef90_123',['shopping.f90',['../shopping_8f90.html',1,'']]],
  ['sigma_124',['sigma',['../namespacevariables.html#a52086073bad64f461333d8f6b0381eb0',1,'variables']]],
  ['sigmap_5finit_125',['sigmap_init',['../namespacevariables.html#aba9995d51a0298c8111345f0a656b16c',1,'variables']]],
  ['sigmar_5finit_126',['sigmar_init',['../namespacevariables.html#ae25d2599dbf45a48a5bcf469c3d17ec8',1,'variables']]],
  ['spin_5fdia_127',['spin_dia',['../namespacevariables.html#ab043484be6fb6d8c4ad8598b38118394',1,'variables']]]
];
