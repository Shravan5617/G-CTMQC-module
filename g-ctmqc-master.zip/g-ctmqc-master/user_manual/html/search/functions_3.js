var searchData=
[
  ['decoherence_5fcoorection_183',['decoherence_coorection',['../namespaceshopping.html#a1e73fe534aa7891ff431291c94ab2a16',1,'shopping']]],
  ['diagonalize_184',['diagonalize',['../namespaceanalytical__potentials.html#a659155b761baaa9ff7d93276000a0a7d',1,'analytical_potentials']]],
  ['doublewell_5fpotential_185',['doublewell_potential',['../namespaceanalytical__potentials.html#ab188600744505c80905a6cae729ab5d1',1,'analytical_potentials']]]
];
