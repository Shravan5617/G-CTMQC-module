var searchData=
[
  ['main_201',['main',['../main_8f90.html#a8ec2266d83cd6c0b762cbcbc92c0af3d',1,'main.f90']]],
  ['momentum_5fcorrection_202',['momentum_correction',['../namespaceshopping.html#ada8f3a7445deb0d07a5a8b43bb6f92c0',1,'shopping']]]
];
