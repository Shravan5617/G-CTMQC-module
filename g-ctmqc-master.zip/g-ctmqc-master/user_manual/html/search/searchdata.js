var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwz",
  1: "acekostvw",
  2: "acekmostvw",
  3: "abcdefghimnpqrsu",
  4: "abcdfhijklmnopqrstvwz"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Namespaces",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

