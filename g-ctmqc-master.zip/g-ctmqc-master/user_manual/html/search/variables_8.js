var searchData=
[
  ['k0_247',['k0',['../namespacevariables.html#a2baa17a4e682051a99a5a9aae3fef710',1,'variables']]],
  ['k_5finit_248',['k_init',['../namespacevariables.html#a9cd0eab367bc3601efcf4bf89c26af6a',1,'variables']]],
  ['k_5fli_249',['k_li',['../namespacetime__evolution.html#a090b86991c4ac03700524805420c1aa7',1,'time_evolution']]]
];
