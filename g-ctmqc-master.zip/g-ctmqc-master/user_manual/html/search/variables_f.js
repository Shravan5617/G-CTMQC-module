var searchData=
[
  ['r0_280',['r0',['../namespacevariables.html#adbab92a50e7cdee9a6e5c6aae5e315df',1,'variables']]],
  ['r02_281',['r02',['../namespacevariables.html#ac899ae2f2df0c3aa9e5d99c6ba034fda',1,'variables']]],
  ['r_5finit_282',['r_init',['../namespacevariables.html#a69578646e2aa0d32889120d5b8359110',1,'variables']]],
  ['rcl_283',['rcl',['../namespacetime__evolution.html#a8b47f0e4068cefb6882176fc50bce59b',1,'time_evolution']]]
];
