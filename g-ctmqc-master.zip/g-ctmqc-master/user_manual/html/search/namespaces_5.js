var searchData=
[
  ['shopping_156',['shopping',['../namespaceshopping.html',1,'']]]
];
