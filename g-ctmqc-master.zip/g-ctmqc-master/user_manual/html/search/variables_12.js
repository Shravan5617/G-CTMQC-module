var searchData=
[
  ['var_5fmomentum_292',['var_momentum',['../namespacevariables.html#a8fb4033efb4387a7058333d13806444d',1,'variables']]],
  ['vcl_293',['vcl',['../namespacetime__evolution.html#aa8e42cd8e2cced352ccbe27d78ac6b47',1,'time_evolution']]]
];
