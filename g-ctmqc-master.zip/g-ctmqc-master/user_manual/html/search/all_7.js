var searchData=
[
  ['hbar_49',['hbar',['../namespacevariables.html#a4f7c4b76127660a6ab1b9c2d0ced2757',1,'variables']]],
  ['hopping_50',['hopping',['../namespaceshopping.html#a337e7b61b2198ac64f3e6ee8a26abee6',1,'shopping']]]
];
