var searchData=
[
  ['zero_295',['zero',['../namespacevariables.html#ab23eef0a897c91d12e4c94e471d25eac',1,'variables']]]
];
