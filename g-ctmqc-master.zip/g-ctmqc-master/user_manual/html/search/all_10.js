var searchData=
[
  ['qmom_5fforce_110',['qmom_force',['../namespacevariables.html#a610698c08f69dd42fe82f46c85dc5538',1,'variables']]],
  ['qp_111',['qp',['../namespacekinds.html#ab9ae202470c73e48421f18653821469b',1,'kinds']]],
  ['quantum_5fmomentum_112',['quantum_momentum',['../namespacecoherence__corrections.html#a982938b35739c7630cfcd56808b3882c',1,'coherence_corrections']]]
];
