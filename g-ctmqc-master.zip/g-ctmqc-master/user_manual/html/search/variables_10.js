var searchData=
[
  ['sigma_284',['sigma',['../namespacevariables.html#a52086073bad64f461333d8f6b0381eb0',1,'variables']]],
  ['sigmap_5finit_285',['sigmap_init',['../namespacevariables.html#aba9995d51a0298c8111345f0a656b16c',1,'variables']]],
  ['sigmar_5finit_286',['sigmar_init',['../namespacevariables.html#ae25d2599dbf45a48a5bcf469c3d17ec8',1,'variables']]],
  ['spin_5fdia_287',['spin_dia',['../namespacevariables.html#ab043484be6fb6d8c4ad8598b38118394',1,'variables']]]
];
